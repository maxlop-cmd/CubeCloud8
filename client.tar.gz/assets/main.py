import sys
import asyncio
import pygame
import time
import math

# --- EINSTELLUNGEN ---
# Deine feste Render.com Server-Adresse (Kein JSONBin mehr nötig!)
HOST_DOMAIN = "online-ewcz.onrender.com"

is_browser = sys.platform in ("emscripten", "wasi")

to_pop = []
player_x, player_y = 100, 100
player2_x, player2_y = 100, 100
player_speed = 5
player_size = 50
player2_adress = "Warte auf P2..."
running = True
text_box = pygame.Rect((268, 260, 260, 55))
enter_box = pygame.Rect((298, 335, 200, 55))
player_colors = [(26, 184, 113), (26, 87, 186), (247, 129, 20), (245, 70, 47), (245, 222, 47), (186, 47, 245)]

color_inactive2 = (70, 70, 70)
color_active2 = (55, 55, 55)
color_disable2 = (40, 40, 40)
color_inactive = (45, 45, 45)
color_active = (55, 55, 55)
color = color_inactive
color2 = color_inactive2

max_timeout_message = 0
pygame.display.init()
pygame.font.init()
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 28)
name = ""
ask_name = True
text = ""
active = False
tick = 0
active2 = False
name = ""
name_e = ""
player2_name = None
connecting_status = None
connecting_status2 = None
points = 35
players = {}
allowed_letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                   "U", "V", "W", "X", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
ws_local = None
p_name = None
ws_url = None
messages = []
names =[]
self_color = None

def zeige_status(text, farbe=(255, 255, 255)):
    screen.fill((30, 30, 30))
    txt = font.render(text, True, farbe)
    screen.blit(txt, (40, 40))
    pygame.display.flip()

async def receive_message(ws):
    global parts, p_name, p_x_, p_y, name, names
    ws_local = ws
    try:
        messages = []
        names = []
        async for message in ws_local:
            if not message in messages:
                messages.append(message)
            if message and message.count(",") == 3:
                parts = message.split(",")
                p_name = parts[1].strip()
                p_x = int(parts[2].strip())
                p_y = int(parts[3].strip())
                if not p_name in names:
                    names.append(p_name)
                if p_name != name:  # Eigene Position nicht überschreiben
                    players[p_name] = (p_x, p_y, max_timeout_message)
    except Exception as error:
        print("fehler in receive message:", error)

async def check_connection():
    global connecting_status, connecting_status2, ws_url, ws_local, adress
    ws_local = None

    if is_browser:
        import platform
        window = platform.window
        # Native JS-WebSocket Steuerung
        window.eval(f"""
            window.socketStatus = "CONNECTING";
            window.latestMsg = "";
            try {{
                window.gameSocket = new WebSocket("{ws_url}");
                window.gameSocket.onopen = function() {{ window.socketStatus = "OPEN"; }};
                window.gameSocket.onmessage = function(e) {{ window.latestMsg = e.data; }};
                window.gameSocket.onerror = function() {{ window.socketStatus = "ERROR"; }};
                window.gameSocket.onclose = function() {{ window.socketStatus = "CLOSED"; }};
            }} catch(e) {{
                window.socketStatus = "ERROR";
            }}
        """)
        for _ in range(50):
            status = str(window.socketStatus)
            if status == "OPEN":
                break
            if status in ("ERROR", "CLOSED"):
                break
            await asyncio.sleep(0.1)

        if str(window.socketStatus) != "OPEN":
            connecting_status = "Server is offline"
            connecting_status2 = "Starting server"
            await asyncio.sleep(0.2)
            await check_connection()

    else:
        import websockets
        try:
            ws_local = await websockets.connect(ws_url)
            adress = await ws_local.recv()
            """
            async def receive_messages():
                global player2_x, player2_y, player2_adress, connecting_status
                try:
                    async for message in ws_local:
                        if message and message.count(",") == 3:
                            parts = message.split(",")
                            current_player_adress = parts[0].strip()
                            current_player_name = parts[1].strip()
                            current_player_x = int(parts[2].strip())
                            current_player_y = int(parts[3].strip())
                except:
                    pass"""
            asyncio.create_task(receive_message(ws_local))

        except Exception as error:
            connecting_status = "Server is offline or unavailable"
            connecting_status2 = "Starting server"
            await asyncio.sleep(0.2)
            await check_connection()
    connecting_status = "Connected to server"
    connecting_status2 = ""


async def connecting():
    global connecting_status, ws_url, connecting_status2
    # --- WEBSOCKET VERBINDUNG ---
    ws_url = f"wss://{HOST_DOMAIN}"
    connecting_status = "Connecting to server"

    await asyncio.sleep(0.1)
    await check_connection()


async def main():
    global player_x, player_y, player2_x, player2_y, player2_adress, running, color_inactive, color_active, color, text, active, tick, color2, color_inactive2, color_active2, ask_name, active2, name_e, points, ws_local, adress, name, parts, p_address, p_name, p_x_, p_y, name, messages, names, max_timeout_message, self_color

    await asyncio.sleep(0)

    task = asyncio.create_task(connecting())

    while ask_name:
        await asyncio.sleep(0)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Aktivieren/Deaktivieren per Mausklick
            active2 = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if enter_box.collidepoint(event.pos):
                    if len(text) == 3:
                        active2 = True
                        screen.fill((0, 0, 255))
                        pygame.display.flip()

                    elif len(text) == 0:
                        name_e = "Type in username"
                else:
                    active2 = False
                if name_e == "":
                    color2 = color_active2 if active2 else color_inactive2
                    if active2:
                        screen.fill((0, 255, 0))
                        pygame.display.flip()

                if text_box.collidepoint(event.pos):
                    if not active:
                        tick = 70
                    active = True
                else:
                    active = False
                color = color_active if active else color_inactive


            # Tastatureingaben verarbeiten
            if event.type == pygame.KEYDOWN and active:
                if event.key == pygame.K_RETURN:
                    if len(text) == 3:
                        active2 = True
                    else:
                        name_e = "Username too short"

                elif event.key == pygame.K_BACKSPACE:
                    text = text[:-1]
                elif len(text) < 3:
                    if str(event.unicode).upper() in allowed_letters:
                        text += str(event.unicode).upper()
        """if connecting_status != "Connected to server":
            color2 = color_disable2
        elif color2 == color_disable2:
            color2 = color_inactive2"""
        screen.fill((30, 30, 30))
        # text input box anzeigen
        name_e = ""
        color2 = color_inactive2
        if 0 < len(text) < 3:
            name_e = "Username too short"
            color2 = color_disable2

        elif text in names:
            name_e = "Username already taken"
            color2 = color_disable2

        elif connecting_status != "Connected to server":
            color2 = color_disable2
        elif len(text) == 0:
            color2 = color_disable2

        #elif name_e != "Type in username":
        screen.blit(pygame.font.SysFont(None, 50).render("Enter username:", True, (255, 255, 255)), (262, 200))
        # enter button anzeigen
        pygame.draw.rect(screen, color, text_box, border_radius=5)
        screen.blit(pygame.font.SysFont(None, 55).render(str(text), True, (255, 255, 255)), (270, 270))
        if active and tick > 0:
            pygame.draw.line(screen, (255, 255, 255), (270 + 3 + pygame.font.SysFont(None, 55).render(str(text), True,(255, 255,255)).get_size()[0], 265), (270 + 3 + pygame.font.SysFont(None, 55).render(str(text), True, (255, 255, 255)).get_size()[0], 305), 3)
        pygame.draw.rect(screen, color2, enter_box, border_radius=5)
        screen.blit(pygame.font.SysFont(None, 55).render("ENTER", True, (80,80,80) if color2 == color_disable2 else (230,230,230)), (330, 345))
        if name_e:
            screen.blit(pygame.font.SysFont(None, 55).render(str(name_e), True, (100, 100, 100)),(400 - pygame.font.SysFont(None, 55).render(str(name_e), True, (100, 100, 100)).get_width() / 2,400))

        if connecting_status != None:
            screen.blit(pygame.font.SysFont(None, 30).render(str(connecting_status) + (
                "." * (math.floor(points / 90) if connecting_status in ("Connecting to server") else 0)),
                True,(255,255,255)), (650 -pygame.font.SysFont(None, 30).render(str(connecting_status),
                True,(255,255,255)).get_size()[0] / 2 - (math.floor(points / 90) *
                pygame.font.SysFont(None,30).render(".", False, (255,255,255)).get_size()[0] / 2) if 800 +
                pygame.font.SysFont(None,30).render(str(connecting_status),True,(255,255,255)).get_size()[0] / 2 < 850 else 800 -
                pygame.font.SysFont(None,30).render(str(connecting_status),True,
                (255,255,255)).get_size()[0] - 40 - (math.floor(points / 90) *pygame.font.SysFont(None,30).render(".",False,
                (255,255,255)).get_size()[0] / 2 if connecting_status in ("Connecting to server") else 0),40))

        if connecting_status2 != None:
            screen.blit(pygame.font.SysFont(None, 30).render(str(connecting_status2) + ("." *
                (math.floor(points / 90) if connecting_status2 in ("Starting server", "Connecting to server") else 0)),True, (255,255,255)), (650 - pygame.font.SysFont(None,30)
                .render(str(connecting_status2), True, (255,255,255)).get_size()[0] / 2 - (math.floor(points / 90) * pygame.font.SysFont(None,30)
                .render(".",False,(255,255,255)).get_size()[0] / 2) if 800 +pygame.font.SysFont(None,30).render(str(connecting_status2),True,
                (255,255,255)).get_size()[0] / 2 < 850 else 800 -pygame.font.SysFont(None,30).render(str(connecting_status2),True,
                (255,255,255)).get_size()[0] - 40 - (math.floor(points / 90) *pygame.font.SysFont(None,30).render(".",False,(255,255,255)).get_size()[0] / 2 if connecting_status in ("Connecting to server") else 0),80))

        if active2 and connecting_status == "Connected to server" and color2 != color_disable2:
            screen.fill((255, 255, 255))
            pygame.display.flip()
            await asyncio.sleep(0.2)
            ask_name = False

        points += 1
        if points >= 360:
            points = 0

        pygame.display.flip()
        tick -= 1
        if tick < -70:
            tick = 70
        clock.tick(100)

    name = text
    pygame.draw.rect(screen, (200, 100, 100), pygame.Rect(380, 0, 40, 40))
    pygame.display.flip()

    # --- HAUPT-SPIELSCHLEIFE ---
    players[name] = (100, 100)
    while running:
        max_timeout_message = round(time.time())
        for player in players:
            if player != name and players[player][2] < max_timeout_message - 1:
                players[player] = (None, None, 0)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]: players[name] = players[name][0] - player_speed, players[name][1]
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: players[name] = players[name][0] + player_speed, players[name][1]
        if keys[pygame.K_UP] or keys[pygame.K_w]: players[name] = players[name][0], players[name][1] - player_speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]: players[name] = players[name][0], players[name][1] + player_speed

        if players[name][0] < 0: players[name] = 0, players[name][1]
        if players[name][0] > screen_width - player_size: players[name] = screen_width - player_size, players[name][1]
        if players[name][1] < 0: players[name] = players[name][0], 0
        if players[name][1] > screen_height - player_size: players[name] = players[name][0], screen_height - player_size

        # --- IN DER HAUPTSCHLEIFE ---

        if is_browser:
            print("browser")
            # --- BROWSER (PYGBAG) ---
            msg = str(window.latestMsg)
            pygame.draw.rect(screen, (100, 200, 100), pygame.Rect(380, 0, 40, 40))
            pygame.display.flip()

            if msg:
                parts = msg.split(",")
                p_address = parts[0].strip()
                p_name = parts[1].strip()
                p_x = int(parts[2].strip())
                p_y = int(parts[3].strip())

                if p_name != name:
                    players[p_name] = (p_x, p_y)

                window.latestMsg = ""  # Nachricht leeren!

            if str(window.socketStatus) == "OPEN":
                pygame.draw.rect(screen, (100, 100, 200), pygame.Rect(420, 0, 40, 40))
                pygame.display.flip()

                # Einzelne Variablen senden statt dem Tupel players[name]!
                werte = f"{None}, {name}, {players[name][0]}, {players[name][1]}"
                window.eval(f'window.gameSocket.send("{werte}");')
            pygame.draw.rect(screen, (0,0,0,), pygame.Rect(420, 0, 40, 40))
            pygame.display.flip()

        else:
            # --- DESKTOP (PC) ---
            if ws_local:
                try:
                    werte = f"{adress}, {name}, {players[name][0]}, {players[name][1]}"
                    await ws_local.send(werte)
                except Exception as error:
                    print("fehler bei senden von daten:", error)

        screen.fill((35, 35, 35))
        for i, player in enumerate(players):
            if player == name:
                self_color = i
        pygame.draw.rect(screen, (min(player_colors[self_color % 6][0] +30, 255), min(player_colors[self_color % 6][1] +30, 255), min(player_colors[self_color % 6][2] +30, 255)), (0, 0, 800, 600), 5)
        for i, player in enumerate(players):
            current_player_x = players[player][0]
            current_player_y = players[player][1]
            if current_player_x != None:
                pygame.draw.rect(screen, player_colors[i % 6], (current_player_x, current_player_y, player_size, player_size))
                screen.blit(pygame.font.SysFont(None, round(player_size / round(
                    pygame.font.SysFont(None, 30).render(str(player), True, (255, 255, 255)).get_width()) * 27)).render(str(player), True, (255, 255, 255)),
                    (current_player_x + player_size / 2 - pygame.font.SysFont(None,round(player_size / round(pygame.font.SysFont(None,30).render(str(player),True,(255,255,255)).get_width()) * 27)).render(str(player),
                    True, (255, 255, 255)).get_width() / 2,current_player_y + player_size / 2 - pygame.font.SysFont(None,round(player_size / round(pygame.font.SysFont(None,30).render(str(player),True,(255,255,255)).get_width()) * 27)).render(
                    str(player), True, (255, 255, 255)).get_height() / 2 + round(player_size / round(
                pygame.font.SysFont(None, 30).render(str(player), True,(255, 255,255)).get_width()) * 27 / 25)))

        # pygame.draw.rect(screen, (230, 50, 50), (player_x, player_y, player_size, player_size))
        # pygame.draw.rect(screen, (50, 230, 50), (player2_x, player2_y, player_size, player_size))
        screen.blit(pygame.font.SysFont(None, 25).render(f"FPS: {round(clock.get_fps()/5)*5}", True, (255,255,255)),(680, 38))
        screen.blit(pygame.font.SysFont(None, 25).render(f"NAME: {name}", True, (255,255,255)),(680, 20))

        pygame.display.flip()
        clock.tick(100)
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())